class LightingModel {

	init( /*input, stack, builder*/ ) { }

	direct( /*input, stack, builder*/ ) { }

	indirectDiffuse( /*input, stack, builder*/ ) { }

	indirectSpecular( /*input, stack, builder*/ ) { }

	ambientOcclusion( /*input, stack, builder*/ ) { }

}

export default LightingModel;
